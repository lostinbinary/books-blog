<?php if(defined('HEADER_SECURITY') != true) die(); ?>

<header>
    <div>
        <a href="/"><?= $messages['logo_name'] ?></a>
        <form id="search">
            <input type="text" id="search_input" placeholder="<?= $messages['search'] ?>" value="<?= $data->search_text ?? '' ?>" />
            <button><img data-src="/assets/img/search-icon.svg" alt="" /></button>
        </form>
    </div>
</header>